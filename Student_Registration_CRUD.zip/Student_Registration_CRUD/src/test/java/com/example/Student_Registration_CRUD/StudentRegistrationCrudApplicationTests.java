package com.example.Student_Registration_CRUD;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StudentRegistrationCrudApplicationTests {

	@Test
	void contextLoads() {
	}

}
